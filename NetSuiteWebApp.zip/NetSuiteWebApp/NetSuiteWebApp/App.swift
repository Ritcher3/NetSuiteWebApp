import SwiftUI

@main
struct NetSuiteWebApp: App {
    var body: some Scene {
        WindowGroup {
            WebContainer()
        }
    }
}
