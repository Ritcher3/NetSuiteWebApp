import SwiftUI
import WebKit

struct WebContainer: UIViewRepresentable {
    
    let urlString = "https://1296498-sb3.extforms.netsuite.com/app/site/hosting/scriptlet.nl?script=5758&deploy=2&compid=1296498_SB3&ns-at=AAEJ7tMQEH_YOHKcT8V0NDfYBaEeZvHWW7U4iz4jc5xqWfvodkA&url=mobile#/login"
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let webview = WKWebView(frame: .zero, configuration: config)
        if let url = URL(string: urlString) {
            webview.load(URLRequest(url: url))
        }
        return webview
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
